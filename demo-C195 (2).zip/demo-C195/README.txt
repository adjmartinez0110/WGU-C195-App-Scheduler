README

- This is a desktop scheduling app created in Java for WGU's C195 course.

- Author: Andy M, Phone: 832-232-1047, Student App Version: 1.0, Date: 11/10/2023

- IDE used is IntelliJ IDEA Community 2022.03, JDK: Oracle OpenJDK 17.0.6, JavaFX: javafx-base-17.0.2

- Program is fully ready to run upon pressing the Play button where LoginMain is found.

- Additional report includes the number of appointments at each of the three distinct locations 
  found in the Appointments table.

- MySQL connector: mysql-connector-java-8.0.25